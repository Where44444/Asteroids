#include "mediumAsteroid.h"
